var temporizador = setTimeout(Chamar_uma_vez,3000);

function Chamar_uma_vez(){
    console.log('Chamei só uma vez');
}
