var elementos = ['Cezar','Diogo','Rafael','Lucas','Andre','Roberto','Maria'];

for(var i = 0; i < elementos.length; i++){
    console.log(elementos[i]);
}