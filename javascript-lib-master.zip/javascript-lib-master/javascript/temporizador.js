var temporizador = setInterval(Chamar,1000);
var tempo = 0;

function Chamar(){
    tempo++;
    console.log(tempo);
}