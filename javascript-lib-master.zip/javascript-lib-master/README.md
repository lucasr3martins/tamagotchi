# javascript-lib
Repositório com soluções matemáticas e computacionais feitas em javascript  
